# Email Feature Bundle

Extracted from the Multi Brand Prompt Generator to port the email-HTML feature into another project.
Folder structure mirrors the source repo — drop files into the same relative paths.

## What's inside

### Core logic (`src/lib/`)
- `build-email-html.ts` — generates a self-contained, table-based, inline-CSS HTML email (Gmail/Outlook safe). Depends on `brand-standards`.
- `build-branded-email.ts` — builds branded email from an `EmailDoc`. Depends on `brand-standards`, `brand-logos`, `brand-headers`, `email-model`.
- `email-model.ts` — the `EmailDoc` / `EmailBlock` data model + helpers (`newBlock`, `moveBlock`, `defaultEmailDoc`, `EMAIL_SAFE_FONTS`, …). No deps.
- `email-templates.ts` — prebuilt templates (`EMAIL_TEMPLATES`, `buildTemplateDoc`). Depends on `email-model`.
- `brand-standards.ts` — per-brand colors/styles (`BRAND_STANDARDS`, `getBrandStyle`, `BRAND_NAMES`, `styleFromColor`). No deps.
- `brand-logos.ts` — `getBrandLogo`. No deps.
- `brand-headers.ts` — `getBrandHeader`, `getBrandHeaderBg` (point at `public/brand-references/*` assets). No deps.
- `deliverability.ts` — `lintDeliverability`, `autoFix`, `sanitizeContent`. No deps.

### UI (React + shadcn/ui + lucide-react + react-router-dom)
- `src/components/EmailHtmlConversionModal.tsx` — modal to convert an image into an email HTML. Uses shadcn `dialog/button/input/label/textarea` and `@/lib/imageStore` (NOT included — app-specific).
- `src/pages/EmailContentChecker.tsx` — full email builder/checker page. Uses shadcn `accordion/button/input/label/textarea` and `@/lib/imageStore` (NOT included).

### Assets (`public/brand-references/<brand>/`)
Header background images referenced by `brand-headers.ts`.

### Database (`scripts/supabase-migrations/`)
- `001_brand_email_config.sql`, `002_brand_email_header.sql` — Supabase tables for per-brand email config.

### Preview / tooling (repo root + `scripts/`)
- `email-samples.html`, `email-samples.mjs` — sample gallery of all brand × variant renders.
- `email-header-textures.html`, `email-header-composites.html` — header previews.
- `scripts/capture_email_*.py` — Playwright screenshot capture scripts.

## Not included (you must provide in the target project)
- `@/lib/imageStore` (localStorage image cache) — used by the two UI files.
- shadcn/ui components (`dialog`, `button`, `input`, `label`, `textarea`, `accordion`).
- `lucide-react`, `react-router-dom`, React.
- The `@/` path alias (Vite `resolve.alias` → `src/`).

## Wiring in the original app
- `src/App.tsx`: `<Route path="/email-content-checker" element={<EmailContentChecker />} />`
- `EmailHtmlConversionModal` is opened from `ImageModal.tsx` and `LikedImageViewModal.tsx`.
